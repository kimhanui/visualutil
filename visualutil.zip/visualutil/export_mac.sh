#!/bin/bash

# === 경로 설정 ===
GODOT_PATH="/Applications/Godot.app/Contents/MacOS/Godot"
PROJECT_PATH="/Users/kimhanui/projects/godot/visualutil"      # ← 너의 프로젝트 경로
EXPORT_PATH="$PROJECT_PATH/Visualutil.app"
EXPORT_NAME="Visualutil"
EXPORT_PRESET="macOS"  # Godot Export Preset 이름 (macOS용)

echo "▶ Export 시작..."

# 1. Export 실행 (.app 생성)
"$GODOT_PATH" --headless --path "$PROJECT_PATH" --export-release "$EXPORT_PRESET" "$EXPORT_PATH"

if [ ! -d "$EXPORT_PATH" ]; then
  echo "❌ Export 실패: .app이 생성되지 않았습니다"
  exit 1
fi

echo "✅ .app export 완료"

# 2. Info.plist 수정 (Dock 아이콘 숨기기)
PLIST="$EXPORT_PATH/Contents/Info.plist"

if ! grep -q "LSUIElement" "$PLIST"; then
  echo "🔧 Info.plist에 LSUIElement 추가..."
  /usr/libexec/PlistBuddy -c "Add :LSUIElement bool true" "$PLIST"
else
  echo "ℹ️ Info.plist에 이미 LSUIElement 설정 있음"
fi

# 3. Gatekeeper 우회
echo "🛡 xattr 제거 (quarantine 해제)"
sudo xattr -rd com.apple.quarantine "$EXPORT_PATH"

# 4. ad-hoc 코드 서명
echo "✍️ 코드 서명"
codesign --force --deep --sign - "$EXPORT_PATH"

echo "🎉 완료: $EXPORT_NAME.app 실행 준비 완료!"
open "$EXPORT_PATH"

